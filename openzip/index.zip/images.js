imageSelect = ["tree1.jpg", "tree2.jpg", "tree3.jpg"]
function changeImage(id){
    document.getElementById("imageBig").src = imageSelect[id]
}